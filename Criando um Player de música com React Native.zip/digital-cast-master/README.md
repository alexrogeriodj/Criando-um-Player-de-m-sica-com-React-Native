# Digital cast

1 - Instalas dependencias do projeto


```bash 
    #com npm
    npm install

    # com yarn
    yarn
```


2 - Execute a api

```bash 

    #com npm 
    npm run api:server

    #com yarn
    yarn api:server
```

3 - Execute o Projeto

```bash 
    #com npm
    npm run start
    #com yarn 
    yarn start 

```
4 - Baixe o aplicativo do expo (Android ou Ios)

5 - Abra o aplicativo e escaneie o QR que abriu em seu navegador 