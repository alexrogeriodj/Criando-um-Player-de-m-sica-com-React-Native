import React from "react";

import Main from "./src";

export default function App() {
  return <Main />;
}
