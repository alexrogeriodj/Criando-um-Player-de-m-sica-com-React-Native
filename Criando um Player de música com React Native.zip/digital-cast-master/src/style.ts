import styled from 'styled-components/native';

export const Background = styled.View`
   background-color: #343a40; 
   flex:1;
`